		
				<!-- Footer -->
		<div id="footer" class="hidden-print">
			
			<!--  Copyright Line -->
			<div class="copy">&copy; 2012 - 2014 - <a href="http://www.mosaicpro.biz">MosaicPro</a> - All Rights Reserved. <a href="http://themeforest.net/?ref=mosaicpro" target="_blank">Purchase CORAL on ThemeForest</a> - Current version: v1.9.6 / <a target="_blank" href="<?= base_url() ?>assets/../../CHANGELOG.txt">changelog</a></div>
			<!--  End Copyright Line -->
	
		</div>
		<!-- // Footer END -->
		
				
	</div>
	<!-- // Main Container Fluid END -->
	

	<!-- Global -->
	<script data-id="App.Config">
	var basePath = '',
		commonPath = '<?= base_url() ?>assets/',
		rootPath = '<?= base_url() ?>',
		DEV = false,
		componentsPath = '<?= base_url() ?>assets/components/',
		layoutApp = false,
		module = 'admin';
	
	var primaryColor = '#eb6a5a',
		dangerColor = '#b55151',
		successColor = '#609450',
		infoColor = '#4a8bc2',
		warningColor = '#ab7a4b',
		inverseColor = '#45484d';
	
	var themerPrimaryColor = primaryColor;
	</script>
	
<script src="<?= base_url() ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/plugins/preload/pace/pace.min.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/core/js/preload.pace.init.js?v=v1.9.6"></script>
<script src="<?= base_url() ?>assets/components/plugins/holder/holder.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/modules/admin/maps/google/assets/custom/maps-google.init.js?v=v1.9.6"></script>
<script src="http://maps.googleapis.com/maps/api/js?v=3&sensor=false&callback=initGoogleMaps"></script>
<script src="<?= base_url() ?>assets/components/common/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/common/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/common/forms/elements/jasny-fileupload/assets/js/bootstrap-fileupload.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/modules/admin/modals/assets/js/bootbox.min.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="<?= base_url() ?>assets/components/core/js/core.init.js?v=v1.9.6"></script>
<script src="<?= base_url() ?>assets/components/core/js/animations.init.js?v=v1.9.6"></script>	
<script src="../assets/components/common/forms/elements/inputmask/assets/lib/jquery.inputmask.bundle.min.js?v=v1.9.6&sv=v0.0.1"></script>
<script src="../assets/components/common/forms/elements/inputmask/assets/custom/inputmask.init.js?v=v1.9.6&sv=v0.0.1"></script>
</body>
</html>
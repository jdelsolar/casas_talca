<?php
/**
* @property CI_Loader $load
* @property CI_Form_validation $form_validation
* @property CI_Input $input
* @property CI_Email $email
* @property CI_DB_active_record $db
* @property CI_DB_forge $dbforge
* @property CI_Table $table
* @property CI_Session $session
* @property CI_FTP $ftp
* @property CI_Pagination $pagination
* ....
*/
class Casas extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }
    
    function agregar(){
        
        $this->form_validation->set_rules('titulo', 'Título', 'required');
        
        $data[0] = '';
        
        if($this->input->post('fotos'))
        {
            foreach ($this->input->post('fotos') as $foto) {
                $data['fotos'][] = $foto;
            }
        }
        
        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('header', $data);
            $this->load->view('casa_form', $data);
            $this->load->view('footer', $data);
        }
        else
        {
            //redirect('agregar_casa');
        }
        
    }
    
}